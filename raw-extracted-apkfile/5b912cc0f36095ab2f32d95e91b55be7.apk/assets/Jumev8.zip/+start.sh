#!/system/bin/sh
/data/data/com.android.mantis.typroxy2/files/tiny -c /data/data/com.android.mantis.typroxy2/files/tiny.conf -p /data/data/com.android.mantis.typroxy2/files/tiny.pid
#以下为自定义脚本:
tiny_check=`ps | grep -i "[T]iny"`
if [[ $tiny_check != "" ]]
then  echo "o tiny 已运行"
else echo "x tiny未运行";fi
/data/data/com.android.mantis.typroxy2/files/SDS.ini
