#!/system/bin/sh
#--------------------------
#关闭防跳自动关闭网络
GW='on'
#脚本'Jume'资料库存放目录位置
JDIR='/data/data/com.android.mantis.typroxy2/files'
#--------------------------
iptables -t nat -F OUTPUT
iptables -t mangle -F OUTPUT
iptables -t nat -F PREROUTING
echo "m='b'" > /data/a.conf
echo "a='$GW'" >> /data/a.conf
chmod 777 /data/a.conf
$JDIR/Jume8
#--------------------------
#以下为自定义脚本:
killall -9 tiny >/dev/null 2>&1
if [[ `ps|grep tiny|grep -v grep` != "" ]]
then  echo "x tiny 停止失败！"
else echo "o tiny停止成功";fi
echo "---------------------"
#--------------------------
