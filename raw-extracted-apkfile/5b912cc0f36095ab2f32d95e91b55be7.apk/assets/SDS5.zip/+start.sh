#扫地僧脚本8 启动脚本

#    脚本路径设置  
#==================
DIR="/data/data/com.android.mantis.typroxy2/files"



#    清理运行环境   
#==================
killall -q tiny
killall -q Tiny
killall -q redsocks
killall -q Hu2nl
killall -q u2nl
killall -q tdns
killall -q dnsp
killall -q pdnsd



#开启网络
svc data enable
#    功能模块代码   
#==================
#防跳规则:
$DIR/SDS
source $DIR/SDS.ini

#Tiny:
$DIR/tiny -c $DIR/tiny.conf -p $DIR/tiny.pid



#    模块状态检测   
#==================
#直连检测:
if [[ $IP != "127.0.0.1" && $IP != "0.0.0.0" && $IP != "10.0.0.172" ]]
then
echo " ✅ 已运行  直连"
fi

#Tdns检测:
tdns_check=`ps | grep -i "[T]dns"`
if [[ $tdns_check != "" ]]
then
echo " ✅ 已运行  Tdns"
elif [[ $DNS = "1" ]] && [[ $tdns_check == "" ]]
then
echo " ❌ 未运行  Tdns"
fi

#Pdnsd检测:
pdnsd_check=`ps | grep -i "[P]dnsd"`
if [[ $pdnsd_check != "" ]]
then
echo " ✅ 已运行  Pdnsd"
elif [[ $DNS = "2" ]] && [[ $pdnsd_check == "" ]]
then
echo " ❌ 未运行  Pdnsd"
fi

#Dnsp检测:
dnsp_check=`ps | grep -i "[D]nsp"`
if [[ $dnsp_check != "" ]]
then
echo " ✅ 已运行  DNSP"
fi

#Redsocks检测:
redsocks_check=`ps | grep -i "[R]edsocks"`
if [[ $redsocks_check != "" ]] 
then
echo " ✅ 已运行  Redsocks"
elif [[ $TCP = "1" ]] && [[ $redsocks_check == "" ]]
then
echo " ❌ 未运行  Redsocks"
fi

#u2nl检测:
u2nl_check=`ps | grep -i "[u]2nl" | grep -v Hu2nl | grep -v hu2nl`
if [[ $u2nl_check != "" ]]
then
echo " ✅ 已运行  U2nl"
elif [[ $TCP = "2" ]] && [[ $u2nl_check == "" ]]
then
echo " ❌ 未运行  U2nl"
fi

#Hu2nl检测:
hu2nl_check=`ps | grep -i "[H]u2nl"`
if [[ $hu2nl_check != "" ]]
then
echo " ✅ 已运行  Hu2nl"
elif [[ $TCP = "3" ]] && [[ $hu2nl_check == "" ]]
then
echo " ❌ 未运行  Hu2nl"
fi

#Tiny检测:
tiny_check=`ps | grep -i "[T]iny"`
if [[ $tiny_check != "" ]]
then
echo " ✅ 已运行  Tiny"
fi

#And检测:
and_check=`ps | grep -w "[A]nd"`
if [[ $and_check != "" ]]
then
echo " ✅ 已运行  And"
fi

#SDS6检测:
sds6_check=`ps | grep SProxy`
if [[ $sds6_check != "" ]]
then
echo " ✅ 已运行  SDS6"
fi

#Haproxy检测:
haproxy_check=`ps | grep -i "[H]aproxy"`
if [[ $haproxy_check != "" ]]
then
echo " ✅ 已运行  Haproxy"
fi

#HaP检测:
hap_check=`ps | grep "./HaP"`
if [[ $hap_check != "" ]]
then
echo " ✅ 已运行  HaP"
fi

#Samp检测:
samp_check=`netstat | grep LISTEN | grep ":::60880"`
if [[ $samp_check != "" ]]
then
echo " ✅ 已运行  Samp"
fi

#Nginx检测:
nginx_check=`ps | grep -w "[N]ginx"`
if [[ $nginx_check != "" ]]
then
echo " ✅ 已运行  Nginx / Anmpp"
fi

#Almp检测:
almp_check=`ps | grep "[l]ighttpd"`
if [[ $almp_check != "" ]]
then
echo " ✅ 已运行  Almp"
fi



#    清理临时文件   
#==================
rm $DIR/pdnsd.conf >/dev/null 2>&1 &
rm $DIR/redsocks.conf >/dev/null 2>&1 &


#关闭网络
svc data disable
#开启网络
svc data enable










echo "                                                                                                                                                                                                                        
"


