#扫地僧脚本8 关闭脚本


#结束相关进程
killall -q tiny
killall -q redsocks
killall -q Hu2nl
killall -q u2nl
killall -q tdns
killall -q dnsp
killall -q pdnsd


#清除防跳规则
iptables -t mangle -F OUTPUT
iptables -t nat -F OUTPUT
iptables -t nat -F PREROUTING
iptables -t mangle -F PREROUTING
iptables -t nat -F SDS1
iptables -t nat -X SDS1
iptables -t nat -F SDS2
iptables -t nat -X SDS2
iptables -t nat -F SDS3
iptables -t nat -X SDS3
#Tiny检测:
tiny_check=`ps | grep -i "[T]iny"`
if [[ $tiny_check != "" ]]
then
echo " ❌ Tiny 停止失败！"
elif [[ $tiny_check == "" ]]
then
echo " ✅ Tiny 停止成功！"
fi
